---
name: Pure Black EdTech
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#d1c6ab'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#9a9078'
  outline-variant: '#4d4632'
  surface-tint: '#eec200'
  primary: '#ffecb9'
  on-primary: '#3c2f00'
  primary-container: '#facc15'
  on-primary-container: '#6c5700'
  inverse-primary: '#735c00'
  secondary: '#4ae176'
  on-secondary: '#003915'
  secondary-container: '#00b954'
  on-secondary-container: '#004119'
  tertiary: '#f7e8ff'
  on-tertiary: '#490080'
  tertiary-container: '#e4c5ff'
  on-tertiary-container: '#7e23cd'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe083'
  primary-fixed-dim: '#eec200'
  on-primary-fixed: '#231b00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#6bff8f'
  secondary-fixed-dim: '#4ae176'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005321'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb7ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6900b3'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  stat-mono-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  stat-mono-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system is tailored for an intensive, high-focus competitive examination and timed quiz environment. The target audience comprises ambitious students, test-takers, and certification candidates operating under high-stakes test scenarios where visual distraction equates to cognitive fatigue.

The design movement combines **Minimalism** with **Tactile Precision**. The UI is built entirely upon true optical pitch blacks (`#000000`), explicitly rejecting tinted dark modes (such as blue-gray or slate hues). Depth is articulated exclusively through razor-sharp 1px boundary lines and restrained, calibrated tonal step-ups. 

The emotional signature is disciplined, authoritative, and focused. The high-contrast interaction paradigm adheres to an uncompromising rule: **one primary electric yellow action per screen**. This guarantees that the user’s next critical path—whether submitting an assessment, advancing a section, or initiating a timed trial—is universally unmistakable.

## Colors

The palette establishes an absolute contrast plane through true neutral grays and pure blacks. It completely eliminates slate or midnight-blue casts to maximize OLED contrast, reduce haloing, and heighten attention during long study periods.

### Surface System
- **Canvas Base (`#000000`)**: True pitch black for root viewports, split panes, and exam backdrops.
- **Surface Level 1 (`#0A0A0A`)**: Elevated containers, standard cards, and side rail canvases.
- **Surface Level 2 (`#121212`)**: Modals, dropdown sheets, active navigation states, and interactive card hovers.
- **Surface Level 3 (`#1A1A1A`)**: Selected answer options and high-elevation utility panels.

### Structural Borders
- **Border Subtle (`#262626`)**: Persistent 1px containment borders on passive cards, dividers, and structural grids.
- **Border Strong (`#3F3F3F`)**: Form inputs, unchecked option containers, and resting interactive states.
- **Border Interactive (`#FACC15`)**: Applied during active focus, keyboard selection, or single-select radio locks.

### Typography & Content
- **Text Primary (`#F5F5F5`)**: Question stems, main headers, critical numerals. High contrast against `#000000` and `#0A0A0A`.
- **Text Secondary (`#A3A3A3`)**: Metadata, explanations, breadcrumbs, unselected choices.
- **Text Disabled / Muted (`#6B6B6B`)**: Placeholders, inactive steps, expired question counters.

### Interactive & Status Accents
- **Accent Primary (`#FACC15`)**: Electric Amber-Yellow. Reserved exclusively for the dominant single CTA per screen. Text on primary is pure `#000000`. Hover state transitions to `#FDE047`.
- **Success (`#22C55E`)**: Correct answers, positive delta stats, accuracy indicators.
- **Danger (`#EF4444`)**: Incorrect selections, expired timers, critical exam warnings.
- **Warning (`#F59E0B`)**: Low time remaining warnings, unattempted balance notices.
- **Review / Bookmark (`#A855F7`)**: Question flagged for later review, revision tags.
- **Info (`#38BDF8`)**: General notices, scoring metric breakdowns, peer percentile indicators.

## Typography

The typography is built entirely on `Inter` to deliver an uncompromising, neutral reading experience with dense readability at smaller scales.

### Numeric Precision Rules
All numerical metrics, examination countdown timers, question numbering grids, and grade calculations **must** enforce CSS `font-variant-numeric: tabular-nums` or `font-feature-settings: "tnum" 1`. This prevents visual layout shifts and jitter as seconds tick down during live exams.

### Editorial Hierarchies
- **Question Stems (`body-lg`)**: Paced at 18px with a 28px line-height, optimized for prolonged, fatiguing comprehension tests.
- **Multiple Choice Options (`body-md`)**: Crisp 15px body copy coupled with 600-weight keys (`A`, `B`, `C`, `D`).
- **Timers & Scores (`stat-mono-lg` / `stat-mono-md`)**: High-contrast, tabular digits paired directly with status color semantics (e.g., `#EF4444` when under 5 minutes).

## Layout & Spacing

### Navigation & Frame Structure
The desktop interface relies on an asymmetric fixed/fluid model:
- **Left Sidebar Navigation**: Fixed width at `260px`, docked flush to the left screen boundary with a right 1px border (`#262626`). It holds identity, active tests, exam categories, and profile stats.
- **Main Examination Stage**: Fluid central column with a maximum reading width of `840px` for question stems and answer option blocks, preventing overly wide line lengths.
- **Right Palette Rail (Live Exams)**: Fixed width at `320px` dedicated to question matrices, timer panels, and section toggles.

### Breakpoints & Adaptations
- **Desktop (≥ 1280px)**: 3-column architecture (Left Sidebar [260px] + Fluid Central Work Area + Right Meta Drawer [320px]).
- **Tablet (768px – 1279px)**: Left sidebar collapses into an icon-rail (`72px`) or sheet drawer; right meta rail tucks behind an on-demand sticky top indicator.
- **Mobile (< 768px)**: Single column with edge margins of `1rem`. The navigation collapses to a drawer, and the test HUD (Timer + Question Jump) is pinned to a sticky top bar (`56px` height) styled with surface `#0A0A0A` and a 1px border-bottom (`#262626`).

## Elevation & Depth

This design system uses **zero fuzzy blur shadows**. Depth and layer separation are engineered purely through surface color hierarchy and 1px borders.

### The Linear Boundary Model
- **Ground (`#000000`)**: Lowest depth. Never has an outline.
- **Base Components / Cards (`#0A0A0A`)**: Elevated from ground using a structural border of `1px solid #262626`.
- **Hover & Focused Overlays (`#121212`)**: Layered directly above `#0A0A0A` using `1px solid #3F3F3F`.
- **Modals, Drawers & Popovers (`#121212`)**: Floated above an absolute `#000000` overlay at 80% opacity (`rgba(0, 0, 0, 0.8)`). Outlined with an exact `1px solid #3F3F3F` perimeter.

### Focus & Interactive Depth
When an interactive item is navigated or activated:
- Shadows are avoided in favor of an inset or outset crisp ring: `box-shadow: 0 0 0 2px #FACC15`.
- This ensures visible boundaries on deep black OLED monitors without ambient glow or bleeding.

## Shapes

The design uses a clean shape hierarchy based on structural intent:
- **Cards, Question Boxes, and Panels**: Bound strictly to `16px` border-radius (`rounded-lg`), establishing distinct modules across the canvas.
- **Action Buttons, Form Inputs, and Option Containers**: Bound strictly to `10px` border-radius, creating an approachable target shape that nests inside 16px cards with consistent margins.
- **Status Pills, Question Index Bubbles, and Badges**: Fully circular (`9999px` / pill-shaped) or compact squares with `6px` radius for tabular grid cells.

## Components

### Buttons
- **Primary Action (Only One Per Screen)**: Background `#FACC15`, text `#000000`, font-weight `600`, border-radius `10px`, padding `12px 24px`. Hover: `#FDE047`. Active: `#EAB308`. Focus: `2px solid #FACC15` with a 2px black offset.
- **Secondary Action**: Background `#121212`, text `#F5F5F5`, border `1px solid #3F3F3F`. Hover: Background `#1A1A1A`, border `#6B6B6B`.
- **Ghost / Utility**: Background transparent, text `#A3A3A3`. Hover: text `#F5F5F5`, background `#121212`.
- **Destructive Action**: Background `rgba(239, 68, 68, 0.1)`, text `#EF4444`, border `1px solid #EF4444`. Hover: Background `#EF4444`, text `#000000`.

### MCQ Answer Option Cards
- **Default State**: Surface `#0A0A0A`, border `1px solid #262626`, radius `10px`, padding `16px 20px`. The index badge (`A`, `B`, `C`, `D`) uses background `#121212`, border `1px solid #3F3F3F`, text `#A3A3A3`.
- **Hover State**: Border shifts to `#3F3F3F`, surface transitions to `#121212`.
- **Selected State**: Surface `#121212`, border `1.5px solid #FACC15`. The index badge switches to background `#FACC15`, text `#000000`, font-weight `700`.
- **Answer Review Mode (Correct)**: Surface `rgba(34, 197, 94, 0.1)`, border `1px solid #22C55E`, text `#F5F5F5`. Badge `#22C55E`, text `#000000`.
- **Answer Review Mode (Incorrect)**: Surface `rgba(239, 68, 68, 0.1)`, border `1px solid #EF4444`, text `#F5F5F5`. Badge `#EF4444`, text `#FFFFFF`.

### Question Matrix Navigation Palette
- Grid of compact 36x36px cells displaying question indices (1 to 100+):
  - **Unvisited**: Surface `#0A0A0A`, border `1px solid #262626`, text `#6B6B6B`.
  - **Answered**: Surface `#121212`, border `1px solid #F5F5F5`, text `#F5F5F5`.
  - **Flagged for Review**: Surface `rgba(168, 85, 247, 0.15)`, border `1px solid #A855F7`, text `#A855F7`.
  - **Current Active**: Ring `2px solid #FACC15`, text `#FACC15`.

### Input Fields & Controls
- **Text Inputs**: Surface `#0A0A0A`, border `1px solid #3F3F3F`, radius `10px`, text `#F5F5F5`, padding `12px 16px`. Placeholder `#6B6B6B`. Focus state uses `border-color: #FACC15` with no fuzzy glow.
- **Radio Buttons & Checkboxes**: 20x20px container, surface `#0A0A0A`, border `1.5px solid #3F3F3F`. When checked: background `#FACC15`, checkmark/dot `#000000`, border `#FACC15`.

### Cards & Container Panels
- Base structural card uses background `#0A0A0A`, border `1px solid #262626`, radius `16px`, padding `24px`.
- Interactive cards receive hover transitions to surface `#121212` and border `#3F3F3F`.

### Timers & Status Badges
- **Exam Countdown Timer**: Segmented container with `#0A0A0A` background, border `1px solid #262626`, radius `8px`, tabular figures (`font-variant-numeric: tabular-nums`). Normal state text `#F5F5F5`; under-5-minute threshold text `#EF4444` with subtle pulse animation.
- **Review / Status Chips**: Radius `9999px`, height `24px`, padding `0 10px`, font size `11px`, font weight `600`. Composed of tinted backgrounds (`15%` opacity) and high-contrast foreground labels.